text = input("Enter a title: ")
length = len(text)
print("The Length of the title is:", length)